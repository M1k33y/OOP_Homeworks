#pragma once
#include "Student.h"
#include <cstring>


int cmp_nume(Student p1, Student p2);
int cmp_mate(Student p1, Student p2);
int cmp_eng(Student p1, Student p2);
int cmp_ist(Student p1, Student p2);
int cmp_medie(Student p1, Student p2);
int cmptot(int maxi1, int maxi2, Student p1, Student p2);
